Super Admin:
email = superadmin@gmail.com
password = Superadmin1

Admin
email = admin@gmail.com
password = Adminpass1

Operators
email = operator@gmail.com
password = Operatorpass1

Technician
email = technician@gmail.com
password = Technicianpass1